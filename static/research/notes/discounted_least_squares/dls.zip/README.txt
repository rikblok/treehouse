dpolyfit

An implementation of "Discounted Least Squares Curve Fitting" (with source code and DOS executable) as described at 

http://www.zoology.ubc.ca/~rikblok/wiki/doku.php?id=random_research:rik_s_notes:discounted_least_squares:start

Released to the public domain,
Rik Blok 2002
Email: rik.blok@ubc.ca
