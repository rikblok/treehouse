// echoread.cc - copies a line from stdin to stdout, kind of like 'echo'.
#include <iostream.h>

main()
{
	char s[256];
	cin.getline(s,256);
	cout << s;
	return 0;
}
