// hello.cc

#include <iostream.h>

main()
{
	cout << "Hello, world!";
	return 0;
}