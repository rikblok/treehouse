                                 DSEM v2.6
                                 =========

Contents
========

1. Introduction
2. Notice
3. File List
4. Requirements
5. Installation
6. Interface
7. Credits
8. Release Notes

-----------------------------------------------------------------------------
1. Introduction
===============

DSEM is my seventh generation stock market simulation, also known
as the Decentralized Stock Exchange Model.  It is described in Chapter 3
of my PhD thesis available from http://rikblok.cjb.net/lib/blok00b.html.

-----------------------------------------------------------------------------
2. Notice
=========

DSEM is free software.

There is no warranty for damages caused by using this software.

Without written permission from the author (Rik Blok), you may not
distribute modified packages of this software, and may not distribute
this software for profit.

Before you send requests, questions and bug reports to the author,
please carefully read this file.  However, feedback is
appreciated.

You may find the latest version of this software at
http://rikblok.cjb.net/phd/dsem/

Rik Blok
rikblok@mail.com
http://rikblok.cjb.net
June 29, 2000

-----------------------------------------------------------------------------
3. File List
============

StockVII.exe - the main program
ReadMe.txt   - this file
source.zip   - source code (Borland C++Builder v1.0)

-----------------------------------------------------------------------------
4. Requirements
===============

Supported operating systems:

	MS-Windows 95/98
	MS-Windows NT 3.51 and 4.0

This software has successfully been tested on a Pentium II computer running 
Windows 98 and a Pentium II running Windows NT 4.0.  It may (?) also run 
in the Windows 3.x environment if the Win32s extension has been 
installed.

-----------------------------------------------------------------------------
5. Installation
===============

Extract and copy all files to a single directory.

This program does not modify the computer in any way except that it adds 
a file StockVII.ini (which contains user preferences) to the program
directory.

To uninstall simply remove all installed files and the file
StockVII.ini.

-----------------------------------------------------------------------------
6. Interface
============

When starting DSEM you are first presented with a "New Simulation"
window.  Consult Chapter 3 of my thesis 
(http://rikblok.cjb.net/lib/blok00b.html)
for the meaning of the parameters.  I recommend you ignore the "Debug"
tab.  When satisfied with the parameter choices, click OK to get to the 
main window.

The main window consists of a menu, toolbar, and two graph panes.  The upper
pane will track the price of the stock and the lower, the volume of shares
traded each day.

The toolbar contains buttons run and pause the simulation and to clear the
graphs (and memory).  (As the simulation proceeds and data are accumulated
drawing the graphs takes longer and longer, slowing down the simulation.
By clearing the graphs you can improve performance.  Make sure you save
your data before you clear the graphs, though...they are erased with the
graphs.)  The toolbar also contains a trackbar which controls the speed 
of the simulation: move it to the left to slow down the simulation and 
consume less processor time, or to the right to speed up the simulation.
(At full throttle the simulation runs as fast as the computer will allow
on a low-priority thread.)

The menus are mostly self-evident but here are the details:

File > Export > Agents - writes the current state of the agents to the
	specified data file (tab-separated values) for inspection.

File > Export > History - writes the price and volume series (since the
	last "Clear") to the selected data file (tab-separated values).

File > Exit - quit sim.

Simulation > New - brings up the "New Simulation" dialog.  Hit "Cancel"
	to keep the current simulation.

Simulation > Run - same as Run button

Simulation > Pause - same as Pause button

Simulation > Clear - same as Clear button

Simulation > Batch Mode - run the simulation in batch mode.  Good for 
	collecting a lot of data for experimentation.  Will automatically
	export agent and history data every user-specified interval and
	can optionally quit the program when the simulation time exceeds
	a user-specified limit.  Disable "Plotting" for maximum speed.

Graphs > * > Copy - copy selected graph to the Windows clipboard

Graphs > * > Print - print selected graph to default printer

View > Inspect Agents - allows the user to view the internal state of each
	agent and directly manipulate their "News Response", "Price Response",
	and "Friction".

About - copyright information

-----------------------------------------------------------------------------
7. Credits
==========

This software is possible due to support from the Peter Wall Institute 
for Advanced Studies, Crisis Points Group 
(http://www.geog.ubc.ca/crpoints/).  Thanks to Prof. Birger Bergersen 
for his enthusiasm and faith in me, to Prof. Alan Kraus for his insight,
and to Casey Clements for the inspiration.

This program was made possible by the generous sharing of program segments
(components) by various experts.  Thanks to:

- Grahame Grieve <grahame@kestral.com.au> and Kestral Computing for
their TxyGraph component (the graph)

- Lucian Wischik <ljw1004@cus.cam.ac.uk> for his TAnimTimer component (a
high-resolution timer) <http://www.wischik.com/lu>

- Fedor Koshevnikov <fkozh@usa.net>, Igor Pavluk <ipavluk@usa.net> and
Serge Korolev <korolev@usa.net> for their TFormStorage component (part
of the RxLib library) <http://rx.demo.ru>

- Troels Skovmand Eriksen <TSEriksen@Cyberdude.com> for his TProject
component (version history)

-----------------------------------------------------------------------------
8. Release Notes
================

8/16/2000 10:39:48 PM: Version 2.6
- adaptive agents now choose completely random new parameters
- simulated commission option (dynamic friction) instead of fixed friction
- records program version and build in export data files
- renamed project from "Stock VII" to "DSEM"

6/25/2000 5:24:51 PM: Version 2.5
- adaptive agents
- renamed Tolerance to Friction in dialogs

6/14/2000 11:05:02 PM: Version 2.4
- allow two point Price Response distribution
- disabled "Scale News by time interval" checkbox

5/12/2000 12:53:32 PM: Version 2.3
- news released at fixed intervals instead of Poisson
- known bug (unresolved): previous price always = 1 on first line of history 
	file
- news interval upped to 8 digit precision

5/8/2000 1:53:58 PM: Version 2.2
- initial i=1/2 and initial p=c/s for each agent (so that total C and S scale 
	simply)
- fixed nasty round-off bug when all frictions identical
- time rescaled so each agent *trades* once per day (N/2 calls per day)
- agents only reply if expect to fill entire order

5/4/2000 10:39:41 PM: Version 2.1
- agents now use friction to limit reply orders too
- time rescaled so N calls per day (each agent calls once per day)
- news scaled by news interval so variance = 1 (always) over one day

4/15/2000 8:50:13 PM: Version 2.0
- (incomplete) support for "market maker" and synchronous updating (trading)

2/15/2000 11:25:52 PM: Version 1.5
- increased max # agents to 1,000,000
- added "Inspect Agents" to allow user to view/modify agent characteristics
 - deviate seed and generator recorded in agent and history files

5/4/99 2:37:07 PM: Version 1.4
- moved news into separate unit news.cpp
- allow multiple replies to be filled with each call
- user can specify interval between exports in batch mode (shorter interval 
	is faster and has higher "resolution" but eats more disk space)
- now user enters average/width parameters in "New Simulation" instead of 
	min/max

4/10/99 11:07:56 PM: Version 1.3
- removed relic code for 2nd order corrections to trades
- fixed: TxyGraph->TAxis->AutoSizing was throwing exceptions when the range 
	was small (zero?)
- agents begin simulation satisfied with initial portfolio
- fixed: round-off error let agents trade volume <= 0 when tolerance == 0
- added Tab for setting random-number parameters DevGenerator and DevSeed

4/9/99 10:32:21 PM: Version 1.2
- fixed: cumulative news was being reset with every Clear
- total cash and shares fixed, independent of number of agents
- caller and replier don't respond to price change they instigated (no longer 
	uses 2nd order corrections)
- removed incomplete code for handling commissions

3/11/99 1:34:15 PM: Version 1.1
- added batch mode (automatic export every hour)
- rescaled time so 1 unit = latent call interval
- saves cumulative news in history file
- added second-order corrections to volume to account for price affecting 
	ideal investment

3/9/99 1:19:40 AM: Project started.

