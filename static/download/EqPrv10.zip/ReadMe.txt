                                 EqnPreview
                         TeX Equation Previewer v1.0
                         ===========================

Contents
========

1. Introduction
2. Notice
3. File List
4. Requirements
5. Installation
6. Usage
7. Credits
8. Release Notes
9. To Do List
10. Known Problems

-----------------------------------------------------------------------------
1. Introduction
===============

I write mathematical papers using a language called TeX.  It uses a
"compiler" to format documents instead of the more familiar WYSIWYG
interface.  I prefer TeX but miss some of the features found in WYSIWYG
word processors (such as Microsoft Word).  In particular, when typing
up equations I like to be able to check that they are correct immediately.
Using TeX this means "compiling" the document, which can take from ten
seconds up to a minute.

I wanted a faster way to check my documents so I wrote EqnPreview.  It
lets you type in an TeX-formatted equation and displays the formatted
equation in (almost) real time.

-----------------------------------------------------------------------------
2. Notice
=========

EqnPreview is free software.

There is no warranty for damages caused by using this software.

Without written permission from the author (Rik Blok), you may not
distribute modified packages of this software, and may not distribute
this software for profit.

Before you send requests, questions and bug reports to the author,
please carefully read this file.  However, feedback is appreciated.

You may find the latest version of this software at
http://rikblok.cjb.net/files.html#EqnPreview
(The address may be changed in future.)

Rik Blok
rikblok@mail.com
http://rikblok.cjb.net/
March 31, 1999

-----------------------------------------------------------------------------
3. File List
============

EqnPreview.exe - the main program
ReadMe.txt     - this file
Source.zip     - source code (Borland C++Builder v1.0)

-----------------------------------------------------------------------------
4. Requirements
===============

Supported operating systems:

	MS-Windows 95/98
	MS-Windows NT 4.0 (I think?)

Extra software required:

	MS Internet Explorer 4
	http://www.microsoft.com/windows/ie/default.htm

    IBM techexplorer Hypermedia Browser 2.5
    http://www.software.ibm.com/network/techexplorer/

This software has successfully been tested on a Pentium II computer
running Windows 95b with Internet Explorer 4.01 and IBM techexplorer
Hypermedia Browser Introductory Edition 2.5 (Preview Release 1).

Internet Explorer and IBM techexplorer are required because the display
pane of the program is simply an Internet Explorer component which calls
the techexplorer plug-in to format the edited text.

-----------------------------------------------------------------------------
5. Installation
===============

Extract and copy the program file EqnPreview.exe to a selected directory.
The other files are not required.

This program creates the files EqnPreview.ini and EqnPreview.tex in the
program folder but does not modify the computer in any other way.

To uninstall simply remove all installed files.

-----------------------------------------------------------------------------
6. Usage
========

Command-line:

	EqnPreview.exe

(no optional parameters)

EqnPreview consists of two panes: the top pane is the Edit Pane and
the bottom is the Display Pane.  Type TeX commands into the top pane
to see the formatted text in the bottom.  The Edit Pane also has a
context-sensitive menu (right mouse click) for quick selecting/editing.

The Display Pane can be updated manually or automatically.  To update
manually, press 'Insert'.  Automatic updating is handled through the
'Update' menu.  Updates can be set to occur immediately after any change
to the Edit Pane or after a preset interval (or disabled).

On start-up the contents of the clipboard are copied to the Edit Pane.
This should make it easier to incorporate EqnPreview into a text editor.
Simply copy the text/equation you want to preview to the clipboard and
run EqnPreview.  The results will be shown in the display.  You can edit
the text until it looks correct and then exit EqnPreview.  The revised
text is copied back into the clipboard and can be pasted into the text
editor to replace the original.

Minimizing EqnPreview also copies the contents of the Edit Pane to the
clipboard.  This allows you to keep EqnPreview running while using your
text editor (faster...no load time).  Running EqnPreview again simply
calls the active copy.

-----------------------------------------------------------------------------
7. Credits
==========

This program was made possible by the generous sharing of program
segments by various experts.  Thanks to:

	IBM for their techexplorer plug-in
    <http://www.software.ibm.com/network/techexplorer/>

    Microsoft for their TWebBrowser ActiveX component (part of
    Internet Explorer) <http://www.microsoft.com/windows/ie/default.htm>

	Fedor Koshevnikov <fkozh@usa.net>, Igor Pavluk <ipavluk@usa.net> and
	Serge Korolev <korolev@usa.net> for their TFormStorage, TAppEvents and
    RxSplitter components (part of the RxLib library) <http://rx.demo.ru>

    Troels Skovmand Eriksen <TSEriksen@Cyberdude.com> for his TProject
    component.

-----------------------------------------------------------------------------
8. Release Notes
================

v1.0 March 31, 1999
	- first release

-----------------------------------------------------------------------------
9. To Do List
=============

Here are some ideas of how I think EqnPreview could be improved.  I'd like
some feedback on these.  Which do you think are important?  If you have
any suggestions of your own please let me know.

- send copy keystroke to editor on startup and paste on exit
- more documentation

-----------------------------------------------------------------------------
10. Known Problems
==================

- none (known! Let me know...)
