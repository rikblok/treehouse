                                 WinPos v1.0
                                 ===========

Contents
========

1. Introduction
2. Notice
3. File List
4. Requirements
5. Installation
6. Usage
7. Release Notes
8. To Do List
9. Known Problems

-----------------------------------------------------------------------------
1. Introduction
===============

WinPos is a simple utility to position any window from the 
command-line.  The window is positioned, optionally resized, and
brought to the foreground.  WinPos is designed for use within 
batch files.

-----------------------------------------------------------------------------
2. Notice
=========

WinPos is free software.

There is no warranty for damages caused by using this software.

Without written permission from the author (Rik Blok), you may not
distribute modified packages of this software, and may not distribute
this software for profit.

Before you send requests, questions and bug reports to the author, 
please carefully read this file.  However, feedback is appreciated.

You may find the latest version of this software at
http://rikblok.cjb.net/files.html#WinPos
(The address may be changed in future.)

Rik Blok
rikblok@mail.com
http://rikblok.cjb.net/
February 26, 2000

-----------------------------------------------------------------------------
3. File List
============

ReadMe.txt    - this file
Source.zip    - source code (Borland C++Builder v1.0)
WinPos.exe    - the main program
NoteTest.bat  - demonstration batch file for use with Notepad

-----------------------------------------------------------------------------
4. Requirements
===============

Supported operating systems:

	MS-Windows 95/98
	MS-Windows NT 3.51 and 4.0

This software has successfully been tested on a Pentium II computer running 
Windows 98.  It may (?) also run in the Windows 3.x environment if the 
Win32s extension has been installed.

-----------------------------------------------------------------------------
5. Installation
===============

Copy WinPos.exe to any desired directory.  No other files are 
required. Note: if the destination directory is not in the DOS path be 
sure to include full path information when calling WinPos.

This program does not create any other files or modify the computer in 
any way.

To uninstall simply remove all installed files.

-----------------------------------------------------------------------------
6. Usage
========

Command-line:

	WinPos.exe "window title" xul yul [width height]

where 
"window title" is the title of the desired window to receive focus.  If
               the window title includes spaces be sure to enclose it in 
               quotes.  
xul & yul are the desired coordinates of the upper left corner of the window,
width (optional) is the desired width of the window, and
height (optional) is the desired height of the window.

If width and height are not specified, the window will be moved but not 
resized.

Warning: the position parameters allow values which would place the window
off the screen (negative or large positive values).  If the window is
accidentally placed off the screen you can bring it back with another call
to WinPos.

WinPos supports wildcards at the beginning and end of the string using 
the asterisk "*".  A wildcard at the beginning of the string allows any 
number of characters before the string in the window title.  Similarly, 
a wildcard at the end of the string allows any number of characters 
after the string to be matched.  See the examples for a demonstration.

If the specified window is not found or an error occurs WinPos exits with 
an error code of 1. This error code can be trapped in batch files with 
"IF ERRORLEVEL 1 ...". If multiple windows match the search criterion, 
a random one of them is chosen and activated.

Examples:

	WinPos "Untitled - *" 0 0 
	        find a window title starting with "Untitled - " and
		move it's upper left corner to (0,0)
		without resizing it.
	WinPos "* - Notepad" 100 100 500 300
		find a window title ending with "- Notepad",
		move it's upper left corner to (100,100), and
		resize it to 500x300 (width x height).

-----------------------------------------------------------------------------
7. Release Notes
================

v1.0  February 26, 2000
	- first release

-----------------------------------------------------------------------------
8. To Do List
==============

- none

-----------------------------------------------------------------------------
9. Known Problems
==================

- none
