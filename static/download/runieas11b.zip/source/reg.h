/*
 From: Mark Wing (markwing@pobox.com)
 Subject: Re: Help needed with Windows NT Registry... 
 Newsgroups: microsoft.public.vc.mfc
 Date: 1999/07/13 
*/
#ifndef regH
#define regH

//#ifdef  __cplusplus
//extern "C" {
//#endif

BOOL ReadRegValue(HKEY root, LPCTSTR strKey, LPCTSTR pszValName, LPBYTE &lpData);
BOOL WriteRegValue(HKEY root, LPCTSTR strKey, LPCTSTR pszValName, LPBYTE lpData);

//#ifdef  __cplusplus
//}
//#endif

#endif // regH
