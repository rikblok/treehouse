                                 CSEM v2.4
                                 =========

Contents
========

1. Introduction
2. Notice
3. File List
4. Requirements
5. Installation
6. Interface
7. Credits
8. Release Notes

-----------------------------------------------------------------------------
1. Introduction
===============

CSEM is my fourth generation stock market simulation, also known
as the Centralized Stock Exchange Model.  It is described in Chapter 2
of my PhD thesis available from http://rikblok.cjb.net/lib/blok00b.html.

-----------------------------------------------------------------------------
2. Notice
=========

CSEM is free software.

There is no warranty for damages caused by using this software.

Without written permission from the author (Rik Blok), you may not
distribute modified packages of this software, and may not distribute
this software for profit.

Before you send requests, questions and bug reports to the author,
please carefully read this file.  However, feedback is
appreciated.

You may find the latest version of this software at
http://rikblok.cjb.net/phd/csem/

Rik Blok
rikblok@mail.com
http://rikblok.cjb.net
June 28, 2000

-----------------------------------------------------------------------------
3. File List
============

StockIV.exe - the main program
ReadMe.txt  - this file
source.zip  - source code (Borland C++Builder v1.0)

-----------------------------------------------------------------------------
4. Requirements
===============

Supported operating systems:

	MS-Windows 95/98
	MS-Windows NT 3.51 and 4.0

This software has successfully been tested on a Pentium II computer running 
Windows 98 and a Pentium II running Windows NT 4.0.  It may (?) also run 
in the Windows 3.x environment if the Win32s extension has been 
installed.

-----------------------------------------------------------------------------
5. Installation
===============

Extract and copy all files to a single directory.

This program does not modify the computer in any way except that it adds 
a file StockIV.ini (which contains user preferences) to the program
directory.

To uninstall simply remove all installed files and the file
StockIV.ini.

-----------------------------------------------------------------------------
6. Interface
============

When starting CSEM you are first presented with a "New Simulation"
window.  Consult Chapter 2 of my thesis 
(http://rikblok.cjb.net/lib/blok00b.html)
for the meaning of the parameters.  I recommend you ignore the "Market"
and "Debug" tabs.  When satisfied with the parameter choices, click OK
to get to the main window.

The main window consists of a menu, toolbar, and two graph panes.  The upper
pane will track the price of the stock and the lower, the volume of shares
traded each day.

The toolbar contains buttons run and pause the simulation and to clear the
graphs (and memory).  (As the simulation proceeds and data are accumulated
drawing the graphs takes longer and longer, slowing down the simulation.
By clearing the graphs you can improve performance.  Make sure you save
your data before you clear the graphs, though...they are erased with the
graphs.)  The toolbar also contains a trackbar which controls the speed 
of the simulation: move it to the left to slow down the simulation and 
consume less processor time, or to the right to speed up the simulation.
(At full throttle the simulation runs as fast as the computer will allow
on a low-priority thread.)

The menus are mostly self-evident but here are the details:

File > Export > Agents - writes the current state of the agents to the
	specified data file (tab-separated values) for inspection.

File > Export > History - writes the price and volume series (since the
	last "Clear") to the selected data file (tab-separated values).

File > Exit - quit sim.

Simulation > New - brings up the "New Simulation" dialog.  Hit "Cancel"
	to keep the current simulation.

Simulation > Run - same as Run button

Simulation > Pause - same as Pause button

Simulation > Clear - same as Clear button

Simulation > Batch Mode - run the simulation in batch mode.  Good for 
	collecting a lot of data for experimentation.  Will automatically
	export agent and history data every user-specified interval and
	can optionally quit the program when the simulation time exceeds
	a user-specified limit.  Disable "Plotting" for maximum speed.

Graphs > * > Copy - copy selected graph to the Windows clipboard

Graphs > * > Print - print selected graph to default printer

About - copyright information

-----------------------------------------------------------------------------
7. Credits
==========

This software is possible due to support from the Peter Wall Institute 
for Advanced Studies, Crisis Points Group 
(http://www.geog.ubc.ca/crpoints/).  Thanks to Prof. Birger Bergersen 
for his enthusiasm and faith in me and to Prof. Alan Kraus for his insight.

This program was made possible by the generous sharing of program segments
(components) by various experts.  Thanks to:

- Grahame Grieve <grahame@kestral.com.au> and Kestral Computing for
their TxyGraph component (the graph)

- Lucian Wischik <ljw1004@cus.cam.ac.uk> for his TAnimTimer component (a
high-resolution timer) <http://www.wischik.com/lu>

- Fedor Koshevnikov <fkozh@usa.net>, Igor Pavluk <ipavluk@usa.net> and
Serge Korolev <korolev@usa.net> for their TFormStorage component (part
of the RxLib library) <http://rx.demo.ru>

- Troels Skovmand Eriksen <TSEriksen@Cyberdude.com> for his TProject
component (version history)

-----------------------------------------------------------------------------
8. Release Notes
================

5/23/2000 7:15:33 PM: Version 2.4
- added 'Stop Time' to Batch Mode
- added 'Display' to Batch Mode
- ask whether to append to data files in Batch mode on first write
- reverted to exponential utility with proportional risk aversion
- renamed project from "Stock IV" to "CSEM"

5/3/2000 9:41:10 PM: Version 2.3
- switched to power-law utility (add <r>^2 to denominator of investment 
	fraction)

4/14/2000 3:41:07 PM: Version 2.2
- changed to investment fraction/return series instead of shares held/price 
	series
- added investment fraction limits
- replaced auction with analytic solution for trading price
- now ignores first price movement when forecasting

1/25/2000 11:12:44 PM: Version 2.1
- polynomial (eg. linear) price history fits instead of just moving averages

1/18/2000 10:58:12 PM: Version 2.0
- copied over from Stock VII v1.4
- updated version of original Stock IV with new GUI and some important 
	changes

