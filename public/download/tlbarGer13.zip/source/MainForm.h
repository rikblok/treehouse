//---------------------------------------------------------------------------
#ifndef MainFormH
#define MainFormH
//---------------------------------------------------------------------------
#include <vcl\Classes.hpp>
#include <vcl\Controls.hpp>
#include <vcl\StdCtrls.hpp>
#include <vcl\Forms.hpp>
#include "SpeedBar.hpp"
#include <vcl\ExtCtrls.hpp>
#include <vcl\Buttons.hpp>
#include "Placemnt.hpp"
#include "SysMenu.hpp"
#include <vcl\Menus.hpp>
#include "statusicon.h"
//---------------------------------------------------------------------------
class TToolbarMainForm : public TForm
{
__published:	// IDE-managed Components
	TFormPlacement *FormPlacement1;
	TPopupMenu *PopupMenu1;
	TMenuItem *mCreateShortcut;
	TStatusIcon *StatusIcon1;
	TMenuItem *mMinimize;
	TImageList *ImageList1;
	TMenuItem *mAbout;
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall FormResize(TObject *Sender);
	void __fastcall ButtonClick(TObject *Sender);
	
	
	void __fastcall FormPlacement1RestorePlacement(TObject *Sender);
	void __fastcall mCreateShortcutClick(TObject *Sender);
	void __fastcall mMinimizeClick(TObject *Sender);
	
	
	void __fastcall FormKeyPress(TObject *Sender, char &Key);
	
	
	void __fastcall FormPaint(TObject *Sender);
	void __fastcall mAboutClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TToolbarMainForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TToolbarMainForm *ToolbarMainForm;
//---------------------------------------------------------------------------
#endif
