//---------------------------------------------------------------------------
#ifndef findwinregexpH
#define findwinregexpH
//---------------------------------------------------------------------------
HWND FindWindowRegexp(AnsiString ClassName, AnsiString WindowName);
#endif
