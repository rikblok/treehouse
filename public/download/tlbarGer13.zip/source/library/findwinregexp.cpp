//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#include <regexp.h>
#include <cstring.h>
#pragma hdrstop

#include "findwinregexp.h"
#include "win32x.h"		// for GetClassNameX() & GetWindowTextX()

// global variables
AnsiString globalClass;
AnsiString globalName;
TRegexp NameRegexp("");
HWND handle;

//---------------------------------------------------------------------------
BOOL CALLBACK ListWindows(HWND hWnd, LPARAM lparam)
/*
	EnumWindowsCallback function to compare window to regular expression.
    Uses global variables and saves window in handle.
*/
{
    AnsiString c = GetClassNameX(hWnd);
    AnsiString ansit = GetWindowTextX(hWnd);
	size_t len;
    // TRegexp.find() needs string not AnsiString for title match
    string t = (ansit.IsEmpty()) ? "": ansit.c_str();
    ansit = t.c_str();

	if ( (globalClass.IsEmpty() ||				// empty fwClass always matches
		  c==globalClass) &&					// or match class name
		 (globalName.IsEmpty() ||				// empty fwNameExp always matches
		  (NameRegexp.find(t,&len)!= -1)) ) {	// or find fwNameExp in t
		handle = hWnd;	// found match
		return false;	// don't continue
	} else
		return true;	// do continue
}
//---------------------------------------------------------------------------
HWND FindWindowRegexp(AnsiString ClassName, AnsiString WindowName)
/*
	As FindWindow() but supports regular expressions for name.  Returns
    first window found matching criteria.
*/
{
	// set global variables before iterating through windows
	globalClass= ClassName;
	globalName = WindowName;
    NameRegexp = globalName.c_str();
    handle = NULL;
    // ok, let's find it!
	EnumWindows((WNDENUMPROC)ListWindows,0);
    return handle;
}
//---------------------------------------------------------------------------
