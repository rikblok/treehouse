//---------------------------------------------------------------------------
#include <vcl\forms.hpp>	// Application
#include <vcl\inifiles.hpp>	// TIniFile
#include <vcl\sysutils.hpp>	// ExtractFile*(), FileExists()
#pragma hdrstop
#include "inifilesx.h"
#include "sysutilsx.h"		// ExtractFileRoot()
#include "win32x.h"			// GetWindowsDirectoryX()
//---------------------------------------------------------------------------
TIniFile *FindIni(AnsiString fn)
/*
	find ini-file fn.  Returns handle to ini file or NULL
*/
{
	AnsiString path; 	// holds path info for various purposes

	// if no filename then use application name
	if (fn.IsEmpty())	fn = ExtractFileRoot(Application->ExeName);

	// if no extension then append .ini
	if (ExtractFileExt(fn).IsEmpty())	fn += ".ini";

	// absolute path specified?
	path = ExtractFileDir(fn);
	if (!ExtractFileDrive(fn).IsEmpty() || (!path.IsEmpty() && path.IsPathDelimiter(1))) {
		if (FileExists(fn))	return new TIniFile(fn);

	// no absolute path specified.  Do search.
	} else {
		// current folder
		path = AnsiString(".\\") + fn;
		if (FileExists(path))	return new TIniFile(path);

		// then program folder
		path = ExtractFilePath(Application->ExeName) + fn;
		if (FileExists(path))	return new TIniFile(path);

		path = GetWindowsDirectoryX() + fn;
		// then windows folder
		if (FileExists(path))	return new TIniFile(path);
	}

	// still not found?  Return NULL
	return NULL;
}
//---------------------------------------------------------------------------
