//---------------------------------------------------------------------------
#ifndef win32xH
#define win32xH
//---------------------------------------------------------------------------
AnsiString GetClassNameX(HWND handle);
HWND       GetFocusX(void);
AnsiString GetFullPathNameX(AnsiString f);
AnsiString GetLongFileName(AnsiString filename);
AnsiString GetWindowsDirectoryX(void);
AnsiString GetWindowTextX(HWND handle);
//---------------------------------------------------------------------------
#endif
