/*
	PUSHKEYS 1.0e for C

	original version 1.0 for Visual Basic
	Copyright by Data Solutions Pty Ltd (ACN 010 951 498)
	All rights reserved.
	Email for info: clatta@ozemail.com.au

	Ported to C by Alexander Frink (Alexander.Frink@Uni-Mainz.DE)
	January 1998.

	This port is as close as possible to the original Visual Basic code.
	See the documentation that comes with the Visual Basic version. It
	uses the same API calls, so it should work under the same
	circumstances as the original version. However, not much effort was
	made to let the code look C-like.

	Usage:
	e.g. PushKeys("Hello World!{enter}");
	Sends 'Hello World!', followed by a Return to the window which
	currently receives the keyboard input.
	To select the window which should receive the keyboard input, use
	the SetForegroundWindow() API (SetActiveWindow() is not always
	sufficient). You can open a handle to an open window based on its
	title with the EnumWindows() and GetWindowText() APIs.

	Revisions:

	v1.0e	Rik Blok <rikblok@mail.com> August 29, 2000
		- allows setting of millisecond delay between keystrokes
		with global variable PushKeySleep=... (>=0, default=0).
	v1.0d	Rik Blok <rikblok@mail.com> August 24, 2000
		- support for executing other programs with {RUN ...} keystroke
		(eg. {RUN notepad.exe c:\windows\win.ini})
	v1.0c	Axel Friedrich <axel.friedrich@operamail.com> and
			Rik Blok <rikblok@mail.com> February 24, 2000
		- German keyboard support with #define GERMAN_KEYBD
	v1.0b	Rik Blok <rikblok@mail.com> December 12, 1998
		- added support for millisecond sleeps via {SLEEP 0.001} etc.
		- added {EMPTYCLIPBOARD}/{EMPTYCLIP} keystroke to empty the
		  clipboard
		- replaced _strupr() routine with strupr()
		- moved internal function prototypes from header file to main
		  file
		- Successfully compiled with Borland C++Builder 1.0 under
		Windows 95b.

	v1.0    Alexander Frink <Alexander.Frink@Uni-Mainz.DE> January 1998
		- ported to C
		- Successfully compiled with Visual C++ 4.2 under Windows NT 4.0
		(Intel).
*/
    
#define MAXLEN 1024 // maximum length of a string passed to PushKeys(), may be increased

extern DWORD PushKeySleep;

#ifdef  __cplusplus
extern "C" {
#endif

void PushKeys(LPCTSTR Source);

#ifdef  __cplusplus
}
#endif


