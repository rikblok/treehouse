//---------------------------------------------------------------------------
#include "inifilesx.h"
#include "VCLUtils.hpp"
//---------------------------------------------------------------------------
USEFORM("MainForm.cpp", ToolbarMainForm);
USERES("Toolbar.res");
USEUNIT("\My Documents\CBuilder\Library\inifilesx.cpp");
USEUNIT("\My Documents\CBuilder\Library\win32x.cpp");
USEUNIT("\Program Files\Borland\CBuilder\AddOns\RX\Units\Rxini.pas");
USEUNIT("\My Documents\CBuilder\Library\pushkeys.c");
USEUNIT("\My Documents\CBuilder\Library\findwinregexp.cpp");
USEFILE("ReadMe.txt");
USEUNIT("\My Documents\CBuilder\Library\sysutilsx.cpp");
USEUNIT("\Program Files\Borland\CBuilder\AddOns\RX\Units\Fileutil.pas");
//---------------------------------------------------------------------------
AnsiString AppTitle = "Toolbar";
TIniFile *ini;
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
	// first validate ini-file
	if (ParamCount()<1) {
		MsgBox(AppTitle,AnsiString("Usage: ") + ExtractFileName(Application->ExeName)
			+ AnsiString("<configuration> [-s]"),MB_OK);
        return 3;
    }
   	ini = FindIni(ParamStr(1));
    if (ini==NULL) {
   		MsgBox(AppTitle, AnsiString("Error: could not find configuration file ")
			+ ParamStr(1),MB_OK);
        return 2;
    }

    // ini-file ok.  Continue.
	try
	{
		AppTitle = ini->ReadString("Toolbar","Title",AppTitle);
        // if already running then close both (for toggle effect)
        if (ActivatePrevInstance("TToolbarMainForm",AppTitle)) {
			HWND h = FindWindow("TToolbarMainForm",AppTitle.c_str());
			// note: if currently in tray, should WM_SHOW not WM_CLOSE
            SendMessage(h,WM_CLOSE,0,0);	// close previous
            return 1;
        }
		Application->Initialize();
		Application->Title = "Toolbar";
		Application->CreateForm(__classid(TToolbarMainForm), &ToolbarMainForm);
		Application->Run();
	}
	catch (Exception &exception)
	{
		Application->ShowException(&exception);
	}
	return 0;
}
//---------------------------------------------------------------------------
