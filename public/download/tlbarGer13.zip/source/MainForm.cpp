//---------------------------------------------------------------------------
/*
	Toolbar
	by Rik Blok, 2002
	http://rikblok.cjb.net/software/toolbar/

	Toolbar (alias Rik's Toolbar) provides a way to add
	a customized floating toolbar to any application.
	When a button is pressed a pre-defined sequence of
	keystrokes is sent to the desired window.
*/
#define TOOLBARVERSION "1.3"
/*
	Revisions:
	v1.3	July 17, 2002
		- added popup menu (right-click)
		- added menu item "Create Desktop Shortcut" to create a shortcut
			on the desktop for this particular toolbar configuration
		- added menu item "Minimize to Tray" to hide toolbar temporarily
			in the tray. Left-click on the icon to restore it.
		- added menu item "About Toolbar" to provide program information
		- support for command-line options "-s[=desktop]" or
			"-s=startmenu[:folder]" to create shortcuts automatically.  If
			folder specified with "-s=startmenu" option then icon put in
			Start Menu > Programs > folder.
*/
//---------------------------------------------------------------------------
#include <win32\shlobj.h>	// for ITEMIDLIST, SHGetSpecialFolderLocation(),
							//     SHGetPathFromIDList()
#pragma hdrstop
#include "MainForm.h"
#include "VCLUtils.hpp"
#include "RxIni.hpp"
#include "FileUtil.hpp"		// for ForceDirectories()
#include "pushkeys.h"
#include "sysutilsx.h"
#include "win32x.h"
#include "findwinregexp.h"
//---------------------------------------------------------------------------
//#pragma link "SpeedBar"
#pragma link "Placemnt"
#pragma link "SysMenu"
#pragma link "statusicon"
#pragma resource "*.dfm"
TToolbarMainForm *ToolbarMainForm;

// defined in Toolbar.cpp
extern AnsiString AppTitle;
extern TRxIniFile *ini;

class TToolbarButton {
	public:
		TSpeedButton *b;
		AnsiString InsertText;	// text to type
		AnsiString Destination;	// destination window pattern to match (reg exp)
		TToolbarButton()
		{
			b = new TSpeedButton(ToolbarMainForm);
			// give button to ToolbarMainForm
			ToolbarMainForm->InsertControl(b);
		}
};

TToolbarButton *buttons;	// an array of buttons (zero indexed)
int ButtonCount = 0;
bool CutAndPaste = false;	// add cut-and-paste keys to all macros
int ButtonWidth = 0;
int ButtonHeight = 0;
//---------------------------------------------------------------------------
int error(LPSTR msg)
/*
	Display an error message and return an error value.
*/
{
	Application->MessageBox(msg, "Error",MB_OK);
	return 1;
}
//---------------------------------------------------------------------------
LPTSTR GetCurrentDirectoryX(void)
/*
	Allocates space for folder name and returns pointer to current folder.
	It is the responsibility of the calling function to free the array.
*/
{
	DWORD nBufferLength = GetCurrentDirectory(0, NULL);
	if (!nBufferLength)	return NULL;
	LPTSTR lpBuffer = new TCHAR[nBufferLength];
	if (!lpBuffer)	return NULL;
	if (nBufferLength > GetCurrentDirectory(nBufferLength, lpBuffer))
		return lpBuffer;
	delete [] lpBuffer;
	return NULL;
}
//---------------------------------------------------------------------------
LPSTR GetSpecialFolderLocation(int nFolder)
//	Requires #include <win32\shlobj.h>.
{
	LPITEMIDLIST pidl;
	if (SHGetSpecialFolderLocation(NULL, nFolder, &pidl) != NOERROR)
		return NULL;

	LPSTR pszPath = new CHAR[MAX_PATH];
	if (SHGetPathFromIDList(pidl,pszPath))	return pszPath;
	delete [] pszPath;
	return NULL;

}
//---------------------------------------------------------------------------
HRESULT CreateLink(LPCSTR lpszPathObj, LPSTR lpszArg, LPSTR lpszWorkDir,
                         LPSTR lpszIcon, int IconIndex, LPSTR lpszPathLink,
                         LPSTR lpszDesc)
/*
	lpszPathObj and lpszPathLink are required.  All other arguments
	are optional (may be empty string, "").

	Author: Jon McCain
	Date: 10/23/99
	Copyright (C) 1999  Surfboy Software
	email: jon@worldofjon.com
	http://www.worldofjon.com/downloads/
*/
{
  HRESULT hres;
  IShellLink* psl;

  CoInitialize(NULL);

  // Get a pointer to the IShellLink interface.
  hres = CoCreateInstance((_GUID)CLSID_ShellLink, NULL,
                          CLSCTX_INPROC_SERVER,
						  (_GUID)IID_IShellLink,
						  (void**)&psl);
  if (SUCCEEDED(hres))
  {
	IPersistFile* ppf;

    // Set the path to the shortcut target, and add the
    // description.
	psl->SetPath(lpszPathObj);
	psl->SetArguments(lpszArg);
	psl->SetWorkingDirectory(lpszWorkDir);
	psl->SetIconLocation(lpszIcon,IconIndex);
	psl->SetDescription(lpszDesc);

	// Query IShellLink for the IPersistFile interface
	//for saving the shortcut in persistent storage.
	hres = psl->QueryInterface((_GUID)IID_IPersistFile,(void**)&ppf);

	if (SUCCEEDED(hres))
	{
	  WORD wsz[MAX_PATH];

	  // Ensure that the string is ANSI.
	  MultiByteToWideChar(CP_ACP, 0, lpszPathLink, -1,
						  (wchar_t*)wsz, MAX_PATH);

	  // Save the link by calling IPersistFile::Save.
	  hres = ppf->Save((wchar_t*)wsz, TRUE);
	  ppf->Release();
	}
	psl->Release();
  }

  CoUninitialize();

  return hres;
}
//---------------------------------------------------------------------------
void createShortcut(int nFolder, AnsiString subfolder="")
{
	// get current folder
	LPTSTR cwd = GetCurrentDirectoryX();
	if (!cwd)	error("Could not locate working folder.");
	// get desktop folder
	LPSTR shortcut = GetSpecialFolderLocation(nFolder);
	if (!shortcut) {
		delete [] cwd;
		error("Could not locate Desktop folder.");
	}
	// append sub-folder
	if (!subfolder.IsEmpty()) {
		lstrcat(shortcut,"\\");
		lstrcat(shortcut,subfolder.c_str());
		ForceDirectories(shortcut);
	}
	// get app path
	LPSTR app = new CHAR[ParamStr(0).Length()+1];
	if (!app) {
		delete [] cwd;
		delete [] shortcut;
		error("Could not allocate space.");
	}
	strcpy(app,ParamStr(0).c_str());
	// create shortcut
	lstrcat(shortcut,"\\");
	// replace bad chars in AppTitle
	AnsiString safeAppTitle = AppTitle;
	safeAppTitle.Unique();	// make new copy of AppTitle
	for (int i=1; i<=safeAppTitle.Length(); i++) {
		if (strchr("<>:\"/\\|*?",safeAppTitle[i]))	safeAppTitle[i]='_';
	}

	lstrcat(shortcut,safeAppTitle.c_str());
	shortcut[251]='\0';	// clip long shortcut
	lstrcat(shortcut,".lnk");
	HRESULT hres = CreateLink(app,ParamStr(1).c_str(),cwd,"",0,shortcut,
							  AppTitle.c_str());
	delete [] cwd;
	delete [] shortcut;
	delete [] app;
	if (!SUCCEEDED(hres))	error("Unknown error.");
}
//---------------------------------------------------------------------------
int TextWidth(const AnsiString s, TFont *f)
/*
	Calculate the width of the string s displayed in the font f.
*/
{
	TCanvas *c = ToolbarMainForm->Canvas;
	c->Font = f;
	return c->TextWidth(s);
}
//---------------------------------------------------------------------------
int TextHeight(const AnsiString s, TFont *f)
/*
	Calculate the height of the string s displayed in the font f.
*/
{
	TCanvas *c = ToolbarMainForm->Canvas;
	c->Font = f;
	return c->TextHeight(s);
}
//---------------------------------------------------------------------------
__fastcall TToolbarMainForm::TToolbarMainForm(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TToolbarMainForm::FormCreate(TObject *Sender)
{
	// default settings
	FormPlacement1->IniFileName = ini->FileName;
	Caption = AppTitle;
	Application->Title = AppTitle;
	ShowHint = ini->ReadBool("Toolbar","ShowHints",false);
	CutAndPaste = ini->ReadBool("Toolbar","CutAndPaste",false);
	AnsiString Destination = ini->ReadString("Toolbar","Destination","");
	PushKeySleep = ini->ReadInteger("Toolbar","Sleep",0);	// v1.2b

	// stay on top? (v1.0c)
	bool onTop = ini->ReadBool("Toolbar","StayOnTop",true);
	if (onTop)	FormStyle = fsStayOnTop;
	else        FormStyle = fsNormal;

	// button on taskbar?  default = no if onTop, else yes (v1.0c)
	if (!ini->ReadBool("Toolbar","TaskbarButton",!onTop))	// if not button
		ShowWindowAsync(Application->Handle,SW_HIDE);		// hide from taskbar

	// button size
	ButtonWidth = ini->ReadInteger("Toolbar","ButtonSize",ButtonWidth);
	ButtonHeight= ini->ReadInteger("Toolbar","ButtonSize",ButtonHeight);

	// get button count from sections
	ButtonCount=1;
	AnsiString section = "Button1";
	while (!ini->ReadString(section,"InsertText","").IsEmpty()) {
		section = AnsiString("Button") + IntToStr(++ButtonCount);	// 1-indexed in ini-file
	}
	ButtonCount--;
	if (ButtonCount==0) {
		MsgBox(AppTitle,"Error: ButtonCount property not found in "
			"configuration file.",MB_OK);
		Close();
	}
	buttons = new TToolbarButton[ButtonCount];
	for (int i=0; i<ButtonCount; i++) {
		section = AnsiString("Button") + IntToStr(i+1);	// 1-indexed in ini-file
		buttons[i].b->Caption = ini->ReadString(section,"Caption","");
		buttons[i].b->Font    = ini->ReadFont(section,"Font",buttons[i].b->Font);
		buttons[i].b->Hint    = ini->ReadString(section,"Hint","");
		buttons[i].InsertText = ini->ReadString(section,"InsertText","");
		buttons[i].Destination= ini->ReadString(section,"Destination",
												Destination /*default*/);
		buttons[i].b->Tag     = i;
		buttons[i].b->OnClick = ButtonClick;
		ButtonWidth = max(ButtonWidth, TextWidth(buttons[i].b->Caption,
												 buttons[i].b->Font) + 4);
		ButtonHeight= max(ButtonHeight,TextHeight(buttons[i].b->Caption,
												  buttons[i].b->Font) + 4);
	}

	// resize buttons
	for (int i=0; i<ButtonCount; i++) {
		buttons[i].b->Width   = ButtonWidth;
		buttons[i].b->Height  = ButtonHeight;
	}

	// set tray icon (v1.3)
	ImageList1->AddIcon(Icon);
	StatusIcon1->Hint = AppTitle;
}
//---------------------------------------------------------------------------
void __fastcall TToolbarMainForm::FormClose(TObject *Sender,
	TCloseAction &Action)
{
	delete [] buttons;
}
//---------------------------------------------------------------------------
void __fastcall TToolbarMainForm::FormResize(TObject *Sender)
{
	int cols = max(1, Width / ButtonWidth);
	int col = 0, row = 0;
	for (int i=0; i<ButtonCount; i++) {
		buttons[i].b->Left = col * ButtonWidth;
		buttons[i].b->Top = row * ButtonHeight;
		col = (col+1) % cols;
		row += (col==0);
	}
}
//---------------------------------------------------------------------------
void __fastcall TToolbarMainForm::ButtonClick(TObject *Sender)
{
	// which button was pressed?
	int index = ((TSpeedButton *)Sender)->Tag;

	// send to which window?
	AnsiString Destination = buttons[index].Destination;

	// build list of keystrokes to send
	AnsiString keys = "";

	// first activate desired window (default to previously active)
	if (Destination.IsEmpty())
		keys += "%{TAB}";	// switch to previous window
	else {
		HWND dest = FindWindowRegexp("",Destination);
		if (dest == NULL || !IsWindow(dest))
			return;			// don't send keys if can't find window
		SetForegroundWindow(dest);
	}
	// if cut-and-pasting then be sure to empty clipboard first
	if (CutAndPaste)	keys += "{EMPTYCLIP}^x";	// empty and cut
	keys += buttons[index].InsertText;	// type
	if (CutAndPaste)	keys += "^v";	// paste
	// ok, let's do it!
	PushKeys(keys.c_str());
}
//---------------------------------------------------------------------------

void __fastcall TToolbarMainForm::FormPlacement1RestorePlacement(
	TObject *Sender)
{
	// check that toolbar window is fully on screen
	if (Height>Screen->Height)	Height = Screen->Height;
	if (Width >Screen->Width)	Width  = Screen->Width;
	if (Top<0)	Top = 0;
	if (Left<0)	Left = 0;
	if (Top+Height>Screen->Height)	Top  = Screen->Height - Height;
	if (Left+Width>Screen->Width)	Left = Screen->Width  - Width;
}
//---------------------------------------------------------------------------
void __fastcall TToolbarMainForm::mCreateShortcutClick(TObject *Sender)
{
	if (Application->MessageBox("Create a shortcut to this toolbar on "
								"the Desktop?",AppTitle.c_str(),MB_YESNO)==IDNO)
		return;
	createShortcut(CSIDL_DESKTOPDIRECTORY);
}
//---------------------------------------------------------------------------
void __fastcall TToolbarMainForm::mMinimizeClick(TObject *Sender)
{
	StatusIcon1->Enabled = !StatusIcon1->Enabled;
	Visible = !StatusIcon1->Enabled;
}
//---------------------------------------------------------------------------
void __fastcall TToolbarMainForm::FormKeyPress(TObject *Sender, char &Key)
{
//	if (Key==27) // user hit Esc key
//		mMinimizeClick(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TToolbarMainForm::FormPaint(TObject *Sender)
/*
	Called when form all property allocated and ready to paint.
	Used to handle command-line parameters.
*/
{
	// if "-s" command-line parameter then create shortcut and exit (v1.3)
	if (ParamCount() >=2) {
		if (	ParamStr(2).LowerCase()=="-s=desktop"
				|| ParamStr(2).LowerCase()=="-s") {
			createShortcut(CSIDL_DESKTOPDIRECTORY);
			Close();
		} else if (ParamStr(2).LowerCase().SubString(1,12)=="-s=startmenu") {
			AnsiString dest = "Toolbar";	// default destination folder
			if (ParamStr(2).Length()>12)
				dest = ParamStr(2).SubString(14,ParamStr(2).Length()-13);
			createShortcut(CSIDL_PROGRAMS,dest.c_str());
			Close();
		}
	}
}
//---------------------------------------------------------------------------
void __fastcall TToolbarMainForm::mAboutClick(TObject *Sender)
{
	AnsiString Text = 	"Toolbar v" TOOLBARVERSION "\n"
						"by Rik Blok, 2002\n"
						"http://rikblok.cjb.net/software/toolbar/\n"
						"\n"
						"Toolbar (alias Rik's Toolbar) provides a way to add\n"
						"a customized floating toolbar to any application.\n"
						"When a button is pressed a pre-defined sequence of\n"
						"keystrokes is sent to the desired window.";
	Application->MessageBox(Text.c_str(), AppTitle.c_str(), MB_OK);
}
//---------------------------------------------------------------------------
