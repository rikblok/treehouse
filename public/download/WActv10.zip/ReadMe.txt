                                 WinActiv v1.0
                                 =============

Contents
========

1. Introduction
2. Notice
3. File List
4. Requirements
5. Installation
6. Usage
7. Release Notes
8. To Do List
9. Known Problems

-----------------------------------------------------------------------------
1. Introduction
===============

WinActiv is a simple utility to activate any window from the 
command-line.  Activating a window brings it to the foreground and makes 
it available for keyboard input.  WinActiv is designed for use within 
batch files.

-----------------------------------------------------------------------------
2. Notice
=========

WinActiv is free software.

There is no warranty for damages caused by using this software.

Without written permission from the author (Rik Blok), you may not
distribute modified packages of this software, and may not distribute
this software for profit.

Before you send requests, questions and bug reports to the author, 
please carefully read this file.  However, feedback is appreciated.

You may find the latest version of this software at
http://rikblok.cjb.net/files.html#WinActiv
(The address may be changed in future.)

Rik Blok
rikblok@mail.com
http://rikblok.cjb.net/
January 8, 1999

-----------------------------------------------------------------------------
3. File List
============

ReadMe.txt    - this file
Source.zip    - source code (Borland C++Builder v1.0)
WinActiv.exe  - the main program
GSreview.bat  - demonstration batch file for use with GSview
waNote.bat    - demonstration batch file for use with Notepad
NoteTest.bat  - another demonstration batch file for use with Notepad

-----------------------------------------------------------------------------
4. Requirements
===============

Supported operating systems:

	MS-Windows 95/98
	MS-Windows NT 3.51 and 4.0

This software has successfully been tested on a Pentium computer running 
Windows 95 and a Pentium II running Windows NT 4.0.  It may (?) also run 
in the Windows 3.x environment if the Win32s extension has been 
installed.

-----------------------------------------------------------------------------
5. Installation
===============

Copy WinActiv.exe to any desired directory.  No other files are 
required. Note: if the destination directory is not in the DOS path be 
sure to include full path information when calling WinActiv.

This program does not create any other files or modify the computer in 
any way.

To uninstall simply remove all installed files.

-----------------------------------------------------------------------------
6. Usage
========

Command-line:

	WinActiv.exe "window title"

where "window title" is the title of the desired window to receive focus.  If
the window title includes spaces be sure to enclose it in quotes.  

WinActiv supports wildcards at the beginning and end of the string using 
the asterisk "*".  A wildcard at the beginning of the string allows any 
number of characters before the string in the window title.  Similarly, 
a wildcard at the end of the string allows any number of characters 
after the string to be matched.  See the examples for a demonstration.

If the specified window is not found WinActiv exits with an error code 
of 1. This error code can be trapped in batch files with "IF ERRORLEVEL 
1 ...". If multiple windows match the search criterion, a random one of 
them is chosen and activated.

Examples:

	WinActiv "Untitled - Notepad"  exact match of "Untitled - Notepad"
	WinActiv "* - Notepad"         match any title ending in " - Notepad"
	WinActiv "Untitled - *"        match any title starting with "Untitled - "
	WinActiv "* - *"               match any title containing " - "
	WinActiv "***"                 match any title containing "*"

-----------------------------------------------------------------------------
7. Release Notes
================

v1.0  January 8, 1999
	- first release

-----------------------------------------------------------------------------
8. To Do List
==============

- don't require quotes around titles with spaces

-----------------------------------------------------------------------------
9. Known Problems
==================

- none
