/*
 * undup.c - remove lines with duplicate UIDs from a sorted CIS user file.
 *
 * Copyright 1988, Jim Mischel.  All rights reserved.
 */
#include <stdio.h>
#include <string.h>
#include "awklib.h"

void main (void) {
    char iline[MAXSTR];
    char uid1[MAXSTR];

    awk_init ();
    uid1[0] = '\0';
    while (getline (iline, MAXSTR, stdin) != EOF) {
	if (strcmp (FIELDS[1], uid1) != 0)
	    printf ("%s\n", iline);
	strcpy (uid1, FIELDS[1]);
    }
}
