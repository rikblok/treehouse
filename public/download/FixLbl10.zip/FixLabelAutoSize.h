//---------------------------------------------------------------------------
#ifndef FixLAbelAutoSizeH
#define FixLAbelAutoSizeH
//---------------------------------------------------------------------------
#include <vcl\SysUtils.hpp>
#include <vcl\Controls.hpp>
#include <vcl\Classes.hpp>
#include <vcl\Forms.hpp>
//---------------------------------------------------------------------------
class TFixLabelAutoSize : public TComponent
{
private:
protected:
public:
	__fastcall TFixLabelAutoSize(TComponent* Owner);
   void __fastcall Loaded(void);
__published:
};
//---------------------------------------------------------------------------
#endif
