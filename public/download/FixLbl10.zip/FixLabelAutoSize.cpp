//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "FixLabelAutoSize.h"
//---------------------------------------------------------------------------
static inline TFixLabelAutoSize *ValidCtrCheck()
{
	return new TFixLabelAutoSize(NULL);
}
//---------------------------------------------------------------------------
__fastcall TFixLabelAutoSize::TFixLabelAutoSize(TComponent* Owner)
	: TComponent(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFixLabelAutoSize::Loaded(void)
{
   // first call OLD loaded handler
   TComponent::Loaded();

	TComponent *c;
	for (int i=0; i<Owner->ComponentCount; i++) {
		c = Owner->Components[i];
		if (c->ClassNameIs("TLabel")) {
			TLabel *l = (TLabel *)c;
			if (l->AutoSize) {
				// force resize
				l->AutoSize = false;
				l->AutoSize = true;
			}
		}
	}
}
//---------------------------------------------------------------------------
namespace Fixlabelautosize
{
	void __fastcall Register()
	{
		TComponentClass classes[1] = {__classid(TFixLabelAutoSize)};
		RegisterComponents("Standard", classes, 0);
	}
}
//---------------------------------------------------------------------------


