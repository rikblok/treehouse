                              FixLabelAutoSize v1.0
                              =====================

Contents
========

1. Introduction
2. Notice
3. File List
4. Requirements
5. Installation
6. Usage
7. Release Notes
8. To Do List

-----------------------------------------------------------------------------
1. Introduction
===============

If you run a Borland C++Builder program on a machine with a different 
resolution or font size than the machine the program was compiled on, 
you may be surprised to find that any labels with the AutoSize property 
set to true may be cropped.  For some reason, they don't AutoSize.  This 
Borland C++Builder VCL component fixes that problem.  Just drop it on 
your form and forget about it!

-----------------------------------------------------------------------------
2. Notice
=========

FixLabelAutoSize is free software.  It may be used for any purpose and 
may be modified in any way desired.  The author takes no responsibility 
for this software.

There is no warranty for damages caused by using this software.  (What 
could that possibly mean?!?)

Before you send requests, questions and bug reports to the author, 
please carefully read this file.  However, feedback is appreciated.

You may find the latest version of this software at
http://rikblok.cjb.net/vcl.html#FixLabelAutoSize
(The address may be changed in future.)

Rik Blok
rikblok@mail.com
http://rikblok.cjb.net/
October 22, 1998

-----------------------------------------------------------------------------
3. File List
============

FixLabelAutoSize.cpp - code
FixLabelAutoSize.h   - header file
FixLabelAutoSize.dcr - glyph for component pallette
ReadMe.txt           - this file

-----------------------------------------------------------------------------
4. Requirements
===============

Borland C++Builder 1.0

This component was developed for Borland C++Builder 1.0 but it should 
also work with later versions.  (I don't know if the same problem exists 
in later versions, though.  Can someone let me know?  Thanks.)

-----------------------------------------------------------------------------
5. Installation
===============

Extract and copy all files to a single directory.  (Preferably some 
generic folder off of the Borland directory, like "$(BCB)\AddOns".)

Install the component normally from within Borland C++Builder.  (Menu 
Component --> Install... --> Add... then enter "<folder 
name>\FixLabelAutoSize.cpp" for the module name.)

To uninstall remove the component from the VCL library.  (Menu Component 
--> Install... then choose FixLabelAutoSize in Installed Components and 
hit Remove.  You may also want to remove the folder from the Search Path 
if no other components are there.)  Once it has been removed from 
Builder simply delete the files.


-----------------------------------------------------------------------------
6. Usage
========

Simply drop the component onto a form and you're done!  All AutoSizing 
labels will now display properly regardless of resolution and font size.

The component works by finding all TLabel components on the form when it 
first loads and (if they have AutoSize=true) toggling AutoSize to false 
and back to true.  Toggling to false has no effect but toggling back to 
true forces the program to recalculate the bounds for the label.

This component has no properties, methods, or events.

-----------------------------------------------------------------------------
7. Release Notes
================

v1.0  October 22, 1998
	- initial release


-----------------------------------------------------------------------------
8. To Do List
=============

- a help file (is this really necessary?)
