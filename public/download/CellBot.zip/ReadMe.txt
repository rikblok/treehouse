                         CellBot ReadMe
                         ==============

Contents:
--------
General Information
Packing List
Boundaries
Rules
Output
Dump File


General Information
-------------------
CellBot is a program I wrote to study the "Game of Life" (GL).	It can 
evolve a cellular automaton in arbitrary dimensions over time, optionally 
disturbing the system when it appears to have stabilized.  A cellular 
automaton is a space which is discrete in both space and time and in 
which each lattice point is represented by a finite number of states.

I used CellBot to run the rules for GL under a variety of boundary 
conditions and system sizes, in order to measure the lifetime of each 
disturbance.  It does not display the cellular automaton as it runs but 
optionally records the lattice configuration or pertinent statistics for 
every time step.

This program is very user unfriendly and has a rather harsh learning 
curve.	It is best suited to researchers familiar with cellular automata 
in general, and GL in particular.  A thorough understanding of the C 
programming language would also be helpful.


Packing List
------------
cbdos.exe	- the CellBot executable for DOS
!!!cbunix	   - the CellBot executable for Unix
!!!ReadMe.txt  - this file
source.zip	- the source code in C
*.rul		- rule files
*.cfg		- configuration files
*.dmp		- dump files


Boundaries
----------
Boundaries are defined by a fixed value in one dimension, such as min_x=-10
or max_x=+10.  CellBot supports a variety of boundary conditions: 

	NONE - no boundary along this edge, the position of the boundary is 
	only used when initially filling the space with random states.
	
	COLD - all cells beyond this boundary are always dead.
	
	HOT x - each cell has a probability x of being in some other state 
	than dead (chosen randomly).  The state of these out-of-bounds cells 
	are constantly in flux, changing every time step.
	
	
	PERIODIC - each cell beyond the border is mapped to a cell on the far 
	side of the lattice, taking the same value.	 In one dimension 
	periodic boundaries would make the space look like a circle.  For 
	example, if | represents a boundary 4|1234|1.
	
	REFLECT_EVEN - a mirror is placed along this boundary reflecting 
	everything within.	For example, if | represents a boundary 1|1234|4.
	
	REFLECT_ODD - as if the mirror was moved halfway into the interior 
	cell so that it reflected the next innermost cells.	 For example, if 
	| represents a boundary 2|1234|3.
	
Because boundaries are imposed at a fixed value of one of the dimensions 
they do not conform to the geometry you may be trying to work with.	 For 
example, even if your rules impose a hexagonal lattice structure, the 
boundaries will still be square, producing odd results.	 Note that the 
boundary locations in the configuration file are inclusive, that is they 
indicate lattice points just within the boundaries.

Corners are accounted for by the order in which the boundaries are listed 
in the configuration file.	The highest priority boundary is listed first 
and imposes it's boundary condition on all edges and corners it covers.  
Subsequently listed boundaries impose their conditions on the remaining 
edges and corners until none are left and the last boundary listed 
affects only it's own space--no edges or corners.


Rules
-----
The rules of evolution are kept in a separate file called a "rule file" 
which has an extension .rul.  CellBot supports two categories of rules: 
the standard local interaction type of rules for a cellular automaton (CA), 
and mixing rules, which move cells within the lattice.	The CA rules 
depend only on the neighborhood of each cell.

The format of the rule file is critical and it can not be rearranged.  
The first line should not be altered even though it is preceded by a 
comment character (#).	The subsequent parameters are:

	Dimensions - the number of dimensions of the lattice space.
	
	States - the minimum and maximum values of the state variable for 
	each site, followed by the default or "dead" state (must be in range).
	
	# Neighbors - the number of neighbors each site can be affected by.	 
	
	Neighbors - a list of "# Neighbors" sets of "Dimensions" integers.	
	Each set represents the relative position of a neighbor site.
	
	Synchronisity - the probability any given site will be updated in 
	each time step.	 Set to 1 for deterministic CA.
	
	Transition Rules - a set of four integers.	The first 2 represent the 
	min. and max. live neighbors required for a transition from dead to 
	alive.	The last two represent the min. and max. live neighbors 
	required to stay alive.	 This section is extremely limited in its 
	functionality (see the source code, file:rules.c, 
	function:applyrules()) and currently only supports 2-state totalistic 
	rules like the "Game of Life".	
	
	Mixing Fraction - fraction of live cells transposed to other sites in 
	each time step.
	
	Mixing Radius - the maximum distance any cell can move.	 If the 
	Mixing Type is "Jump" then the range is just a cube surrounding the 
	cell's original position.  If it is "Walk" then the cell makes 
    "Mixing Radius" steps in a random walk where, in each step, it can 
    step to any empty site in it's neighborhood.
	
	Mixing Type - "Jump" or "Walk".	 When moved cells can either jump 
	directly to a new location anywhere, or can diffuse via a random walk 
	(only over dead sites) through their neighborhoods.
	
	
Output
------
CellBot can output two forms of data: the raw lattice structure of live 
cells can be printed to output files, and/or particular statistics of the 
system can be recorded.	 Further, either of these can be recorded for 
each time step, or only when the system has stabilized.	 The four types 
of data files produced are:

	Cells-Per-Step - filename OutputPrefix#-#.cps where the two numbers 
	are the perturbation count and the current time step.  A new file is 
	generated for each time step, containing a list of coordinates for 
	each live cell followed by the state of the cell.  Must make the 
	OutputPrefix short when running under DOS.
	
	Statistics-Per-Step - filename OutputPrefix#.sps where the number is 
	the perturbation count.	 Generates a new file for each perturbation 
	containing a list of statistics in columns:
	
		Time - current time step in this perturbation.
		
		Activity - the total count of flips from dead to alive and vice 
		versa over the last time step.
		
		more stats - see below
	
	Cells-Per-Pert - filename OutputPrefix#.cpp where the number is the 
	perturbation count.	 Generates a new file as each perturbation dies 
	out, containing a list of coordinates for each live cell followed by 
	the state of the cell.	Gives snapshots of the stable configuration 
	after each perturbation.
	
	Statistics-Per-Pert - filename OutputPrefix.spp (so be sure 
	OutputPrefix is not blank!).  Records statistics at the end of each 
	perturbation in a single file:
	
		Perturbation - count of perturbations so far.
		
		Time - lifetime of last avalanche.
		
		Activity - total activity in last avalanche (including 
		oscillators).
		
		more stats - see below
		
The particular statistics recorded in the .sps and .spp files were 
useful to me for studying the "Game of Life".  Besides those listed above 
there are:

	Live - a count of all live cells in system.
	
	Center of Mass - a set of numbers (one for each dimension) indicating 
	the center of "mass" of the system.	 All non-dead cels are weighted 
	equally.
	
	Half-count Radius - a measure of the size of the system.  
	Extrapolates what the radius of the entire system would be if the 
	density of the interior half were continued.  Useful for measuring 
	the core size when you have a high density core surrounded by low 
	density outliers.
	
	Radius of Gyration - the radius of gyration (as in inertia) around 
	the center of mass.	 Assumes Euclidean geometry.  Estimates the size 
	of the system.
	
	
Dump File
---------
The configuration file contains options which control the usage of a 
dump file, a file which is periodically updated with the latest state of 
the system.	 In the case of a crash the dump file is read and the system 
is restored from the last save.	 

The first line of the dump file is commented out but must not be 
altered.  It contains the version information to ensure that the program 
is compatible with the file.  The following two numbers are the current 
perturbation count and the current time step, respectively.	 Following 
these are a list of numbers, each line containing the position of a live 
cell and the last integer on the line indicating the state of the cell.	 
Only live cells are recorded.

The dump file is named by the Output Prefix in the configuration file 
with an extension .dmp.
