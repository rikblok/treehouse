                        Poor Man's Versioning 1.0
                        =========================

Contents
========

1. Notice
2. File List
3. Requirements
4. Installation
5. Usage
5.1. pmvBackup
5.2. pmvRestore
5.3. pmvRestoreSendTo
6. Known Problems
7. Revisions
8. To-do List
-----------------------------------------------------------------------------
1. Notice
=========

"Poor Man's Versioning" is free software.

Released to the public domain by Rik Blok, 2002.  Use it as you like.
There is no warranty for damages caused by using this software.

Before you send requests, questions and bug reports to the author,
please read this file carefully.  However, feedback is appreciated.

You may find the latest version of this software at
http://rikblok.cjb.net/scripts

Rik Blok
http://rikblok.cjb.net
November 11, 2002
-----------------------------------------------------------------------------
2. File List
============

pmvBackup.cmd        - the backup routine
pmvBackup.exclude    - list of files/folders to exclude from backup
pmvRestore.cmd       - the recovery routine
pmvRestoreSendTo.cmd - "SendTo" interface for pmvRestore.cmd
pmvReleaseInfo.cmd   - used by routines to display release information
ReadMe.txt           - this file
-----------------------------------------------------------------------------
3. Requirements
===============

This program will only run on MS-Windows 2000 or XP.  It relies on some
batch programming extensions not available in Windows 9x or NT.
-----------------------------------------------------------------------------
4. Installation
===============

Extract all the files to a single folder accessible by all users who want to
use it.  No other files are created or needed for installation.

To uninstall, simply delete all files.  If backups have been made using
pmvBackup.cmd then you may want to delete the backup folder as well.
-----------------------------------------------------------------------------
5. Usage
========

Poor Man's Versioning consists of 3 routines: pmvBackup, pmvRestore and 
pmvRestoreSendTo.

5.1. pmvBackup
--------------
This routine is intended to be used by system administrators to periodically
create backups of all changed files in a folder.  

Usage: pmvBackup srcFolder [pmvFolder [pmvVersions]]

The first parameter is the source folder to be backed up.

If the environment variable pmvFolder is defined then the second parameter
is optional, if it is used it overrides the environment variable.  It 
indicates where the backups are to be stored.

Likewise, if the environment variable pmvVersions is defined then 
the third parameter is optional, if it is used it overrides the 
environment variable.  It indicates the maximum number of backups
to store.

Notes:
- Edit pmvBackup.exclude to add any other files/folders you don't
want backed up.
- pmvBackup duplicates security permissions on backed-up files so
users only have access to the backups if they also had access to the
originals.
- It may be a good idea to enable the "Compress contents to save disk
space" folder attribute for the pmvFolder.

Example: pmvBackup "C:\Documents and Settings" C:\Backups\Revisions 28

will keep up to 28 revisions of each file in "C:\Documents and Settings"
storing them in sub-folders of C:\Backups\Revisions.

I have a shortcut with precisely this command line on my machine, and a 
"Scheduled Task" under my Administrator's account to run this shortcut
Daily, in the middle of the night.  That gives me 4 weeks worth of
backups on all my documents.

5.2. pmvRestore
---------------
It is recommended that the user not call pmvRestore directly but instead
use pmvRestoreSendTo which the system administrator can set up for them.

Usage: pmvRestore file [pmvFolder]

The first parameter indicates the file to restore.

If the environment variable pmvFolder is defined then the second parameter
is optional, if it is used it overrides the environment variable.  It 
indicates where the backups are stored.

Example: pmvRestore Rik.mny C:\Backups\Revisions

will find all versions of Rik.mny in C:\Backups\Revisions\ (in the correct
sub-folder) and present them as follows:

    Poor Man's Versioning: Restore
    ------------------------------
    Current version of "Rik.mny":
           "2002/11/11  03:35a             188,416 Rik.mny"
    
    Select version to restore:
      [01] "2002/11/11  03:35a             188,416 Rik.mny"
      [03] "2002/11/10  03:35a             188,416 Rik.mny"
      [04] "2002/11/09  03:35a             188,416 Rik.mny"
      [05] "2002/11/08  03:35a             188,416 Rik.mny"
      [07] "2002/11/06  03:35a             188,416 Rik.mny"
      [08] "2002/11/05  03:35a             188,416 Rik.mny"
      [10] "2002/11/04  03:35a             188,416 Rik.mny"
      [16] "2002/11/03  03:35a             188,416 Rik.mny"
    Version to restore [## or Enter to cancel]:

To restore a version, the user would enter the unique 2 digit number on
the left and hit Enter (or just hit Enter to cancel).  Then the current
file would be renamed to Rik.mny.BAK and the version selected would be
restored.

5.3. pmvRestoreSendTo
---------------------
pmvRestoreSendTo is a convenient interface to the pmvRestore routine.  To use
it the system administrator should edit pmvRestoreSendTo.cmd to change the
pmvFolder variable as necessary and then place a shortcut to pmvRestoreSendTo
in each user's "SendTo" folder.  Give the shortcut a catchy name, like
"Restore Other Version".

Then a user can restore a previous version of a file by simply right-clicking 
on the file, navigating to the "Send To" context menu, and clicking on the 
shortcut to pmvRestoreSendTo.  This will initiate pmvRestore with the correct
backup folder (pmvFolder).

pmvRestoreSendTo can also simultaneously restore a list of files by selecting
multiple files and sending them to the shortcut in the "Send To" folder.
Then each file will be sent to pmvRestore, sequentially.
-----------------------------------------------------------------------------
6. Known Problems
=================

(None known.)
-----------------------------------------------------------------------------
7. Revisions
============

v1.0    November 11, 2002
    - first release
-----------------------------------------------------------------------------
8. To-do List
=============

(Empty.)
-----------------------------------------------------------------------------
